local map = vim.keymap.set

-- File explorer.
map("n", "<Space>e", "<cmd>NvimTreeToggle<cr>", { desc = "Toggle file explorer", silent = true })
map("n", "<Space>E", "<cmd>NvimTreeFocus<cr>", { desc = "Focus file explorer", silent = true })

-- Quality-of-life.
map("n", "<Esc>", "<cmd>nohlsearch<cr>", { desc = "Clear search highlight" })
map("n", "<leader>w", "<cmd>write<cr>", { desc = "Save file", silent = true })
map("n", "<leader>q", "<cmd>quit<cr>", { desc = "Quit window", silent = true })
map("n", "<leader>h", "<cmd>nohlsearch<cr>", { desc = "Clear search highlight", silent = true })

-- Buffers as tabs.
map("n", "<S-l>", "<cmd>bnext<cr>", { desc = "Next buffer", silent = true })
map("n", "<S-h>", "<cmd>bprevious<cr>", { desc = "Previous buffer", silent = true })
map("n", "<leader>x", "<cmd>bdelete<cr>", { desc = "Close buffer", silent = true })

-- Move lines in visual mode.
map("v", "J", ":m '>+1<cr>gv=gv", { desc = "Move selection down" })
map("v", "K", ":m '<-2<cr>gv=gv", { desc = "Move selection up" })
