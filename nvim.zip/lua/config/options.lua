local opt = vim.opt

vim.g.mapleader = " "
vim.g.maplocalleader = "\\"
vim.g.have_nerd_font = true

-- UI: VS Code-like, borderless.
opt.termguicolors = true
opt.winborder = "none" -- Neovim >= 0.11: no floating-window borders.
opt.number = true
opt.relativenumber = true
opt.signcolumn = "yes"
opt.cursorline = false -- cheaper; keeps scrolling fast on mobile.
opt.showtabline = 2
opt.laststatus = 3
opt.cmdheight = 1
opt.splitright = true
opt.splitbelow = true
opt.scrolloff = 8
opt.sidescrolloff = 8
opt.wrap = false
opt.list = false
opt.pumheight = 10
opt.pumwidth = 15
opt.background = "dark"

-- Indentation (C++ friendly).
opt.tabstop = 4
opt.shiftwidth = 4
opt.softtabstop = 4
opt.expandtab = true
opt.autoindent = true
opt.smartindent = true
opt.breakindent = true
opt.shiftround = true
opt.cindent = true
opt.cinoptions:append(":0") -- do not indent case labels.

-- Line spacing. The TUI cannot change terminal cell metrics; the terminal
-- emulator/font must do it. GUI Neovim honours this option.
opt.linespace = 2

-- Editing / performance.
opt.undofile = true
opt.undolevels = 1000
opt.backup = false
opt.writebackup = false
opt.swapfile = false
opt.updatetime = 250
opt.timeoutlen = 300
opt.ttimeoutlen = 10
opt.redrawtime = 1500
opt.ignorecase = true
opt.smartcase = true
opt.inccommand = "nosplit"
opt.confirm = true
opt.mouse = "a"
opt.completeopt = { "menu", "menuone", "noinsert", "noselect" }

-- Diagnostics: compact, no floating border.
vim.diagnostic.config({
  virtual_text = false,
  signs = { text = { "\u{f057}", "\u{f071}", "\u{f05a}", "\u{f0eb}" } },
  underline = true,
  update_in_insert = false,
  severity_sort = true,
  float = { border = "none", source = true },
})

-- Never let a stray netrw instance fight the file explorer.
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
